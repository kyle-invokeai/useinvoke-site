# AI Orchestrator

A CLI tool to route and manage AI agents for tasks like travel, project management, summarization, and more.

## Features
- Interactive prompt loop or direct CLI invocation
- Automatic agent routing and fallback classification
- Airtable and OpenAI integration

## Usage

**Interactive mode:**
```
python -m ai_orchestrator
```

**CLI mode:**
```
python -m ai_orchestrator --agent travel_agent --prompt "Book me a flight to Paris"
```

## Installation
```
pip install -e .
```

## Environment
Create a `.env` file with your API keys:
```
AIRTABLE_API_KEY=your_airtable_key
OPENAI_API_KEY=your_openai_key
```

## License
MIT