from agents.airtable_logger.utils.milestone_updater import update_milestone_status

def summarize_agent(prompt):
    if "summarize project milestones" in prompt.lower():
        update_milestone_status("Summarize project milestones", status="Done", done=True)
        return f"Summary agent completed: {prompt}"
    return f"Summary agent responding to: {prompt}"