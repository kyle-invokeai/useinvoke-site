# Table and field mapping
TABLE_TASKS = 'Tasks'
TABLE_TEAM = 'Team Members'
