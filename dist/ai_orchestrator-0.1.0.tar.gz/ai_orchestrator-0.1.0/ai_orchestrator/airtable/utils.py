# Utility functions for Airtable interactions
