# Airtable API client

import os
import requests
from dotenv import load_dotenv

load_dotenv()

API_TOKEN = os.getenv('AIRTABLE_API_TOKEN')
BASE_ID = os.getenv('AIRTABLE_BASE_ID')
HEADERS = {'Authorization': f'Bearer {API_TOKEN}'}

def get_records(table):
    url = f'https://api.airtable.com/v0/{BASE_ID}/{table}'
    res = requests.get(url, headers=HEADERS)
    return res.json() if res.ok else res.text
