# Logging setup for the orchestrator
